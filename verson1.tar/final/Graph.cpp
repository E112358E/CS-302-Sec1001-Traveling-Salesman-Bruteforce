#include "Graph.h"

#include <iostream>
#include <string>
//by: Elvis Vong
//first version just pure brute force no optimization

Graph::Graph() : startCity(nullptr)
{
}
Graph::Graph(const std::string startingCityname)
{
    startCity = new Vertex;
    startCity->cityName = startingCityname;
}
Graph::~Graph()
{
}

void Graph::setStart(Vertex *newCity)
{
    startCity = newCity;
}
void Graph::removeCity(Vertex *target)
{
    if (target->p1 != nullptr)
    {
        target->p1->weight1 = 0;
        target->p1->p1 = nullptr;
    }
    if (target->p2 != nullptr)
    {
        target->p2->weight2 = 0;
        target->p2->p2 = nullptr;
    }
    if (target->p3 != nullptr)
    {
        target->p3->weight3 = 0;
        target->p3->p3 = nullptr;
    }
    if (target->p4 != nullptr)
    {
        target->p4->weight4 = 0;
        target->p4->p4 = nullptr;
    }

    delete target;
    target = nullptr;
}
void Graph::connectCities(Vertex *cityA, Vertex *cityB, const float edge)
{
    if (cityA->p1 == nullptr && cityB->p1 == nullptr)
    {
        cityA->p1 = cityB;
        cityB->p1 = cityA;

        cityA->weight1 = edge;
        cityB->weight1 = edge;
    }
    else if (cityA->p2 == nullptr && cityB->p2 == nullptr)
    {
        cityA->p2 = cityB;
        cityB->p2 = cityA;

        cityA->weight2 = edge;
        cityB->weight2 = edge;
    }
    else if (cityA->p3 == nullptr && cityB->p3 == nullptr)
    {
        cityA->p3 = cityB;
        cityB->p3 = cityA;

        cityA->weight3 = edge;
        cityB->weight3 = edge;
    }
    else if (cityA->p4 == nullptr && cityB->p4 == nullptr)
    {
        cityA->p4 = cityB;
        cityB->p4 = cityA;

        cityA->weight4 = edge;
        cityB->weight4 = edge;
    }
    else if (cityA->p5 == nullptr && cityB->p5 == nullptr)
    {
        cityA->p5 = cityB;
        cityB->p5 = cityA;

        cityA->weight5 = edge;
        cityB->weight5 = edge;
    }
    else
    {
        std::cout << "Failed, connected City is full" << std::endl;
    }
    
}

float Graph::basicTraversal()
{
    Vertex *temp;
    temp = startCity;
    float distance = 0;
    do
    {
        std::cout << temp->cityName << ' ';
        
        if(temp->p1 != nullptr && !temp->p1->seen && temp->p1 != startCity)
        {
            temp->p1->seen = true;
            distance += temp->weight1;
            temp = temp->p1;
        }
        else if(temp->p2 != nullptr && !temp->p2->seen && temp->p2 != startCity)
        {
            temp->p2->seen = true;
            distance += temp->weight2;
            temp = temp->p2;
        }
        else if(temp->p3 != nullptr && !temp->p3->seen && temp->p3 != startCity)
        {
            temp->p3->seen = true;
            distance += temp->weight3;
            temp = temp->p3;
        }
        else if(temp->p4 != nullptr && !temp->p4->seen && temp->p4 != startCity)
        {
            temp->p4->seen = true;
            distance += temp->weight4;
            temp = temp->p4;
        }
        else if(temp->p5 != nullptr && !temp->p5->seen && temp->p5 != startCity)
        {
            temp->p5->seen = true;
            distance += temp->weight5;
            temp = temp->p5;
        }
        else
        {
            if(temp->p1 == startCity)
            {
                distance += temp->weight1;
                temp = temp->p1;
            }
            else if(temp->p2 == startCity)
            {
                distance += temp->weight2;
                temp = temp->p2;
            }
            else if(temp->p3 == startCity)
            {
                distance += temp->weight3;
                temp = temp->p3;
            }
            else if(temp->p4 == startCity)
            {
                distance += temp->weight4;
                temp = temp->p4;
            }
            else if(temp->p5 == startCity)
            {
                temp = temp->p5;
                distance += temp->weight5;
            }
        }
    } while (temp != startCity);

    std::cout << std::endl;
    return distance;
}

bool Graph::isEmpty()
{
    if (startCity == nullptr)
        return true;
    return false;
}

void Graph::bruteTraversal(Vertex *city, float distance, std::string traversalList)
{
    bool check = true;
    if (city->p1 != nullptr && !city->p1->seen && city->p1 != startCity)
    {
        city->p1->seen = true;
        bruteTraversal(city->p1, distance+city->weight1, traversalList + " -> " + city->p1->getName());
        city->p1->revertSeen();
        check = false;
    }
    if (city->p2 != nullptr && !city->p2->seen && city->p2 != startCity)
    {
        city->p2->seen = true;
        bruteTraversal(city->p2, distance+city->weight2, traversalList + " -> " + city->p2->getName());
        city->p2->revertSeen();
        check = false;
    }
    if (city->p3 != nullptr && !city->p3->seen && city->p3 != startCity)
    {
        city->p3->seen = true;
        bruteTraversal(city->p3, distance+city->weight3, traversalList + " -> " + city->p3->getName());
        city->p3->revertSeen();
        check = false;
    }
    if (city->p4 != nullptr && !city->p4->seen && city->p4 != startCity)
    {
        city->p4->seen = true;
        bruteTraversal(city->p4, distance+city->weight4, traversalList + " -> " + city->p4->getName());
        city->p4->revertSeen();
        check = false;
    }
    if (city->p5 != nullptr && !city->p5->seen && city->p5 != startCity)
    {
        city->p5->seen = true;
        bruteTraversal(city->p5, distance+city->weight5, traversalList + " -> " + city->p5->getName());
        city->p5->revertSeen();
        check = false;
    }

    if (check) //only goes through this if it didn't go through the previous statements
    {
        traversalList += " -> ";
        if (city->p1 == startCity)
        {
            traversalList += city->p1->getName();
            distance += city->p1->weight1;

            std::cout << traversalList << std::endl
                      << "The total distance: " << distance << std::endl << std::endl;
        }
        else if (city->p2 == startCity)
        {
            traversalList += city->p2->getName();
            distance += city->p2->weight2;

            std::cout << traversalList << std::endl
                      << "The total distance: " << distance << std::endl<< std::endl;
        }
        else if (city->p3 == startCity)
        {
            traversalList += city->p3->getName();
            distance += city->p3->weight3;

            std::cout << traversalList << std::endl
                      << "The total distance: " << distance << std::endl<< std::endl;
        }
        else if (city->p4 == startCity)
        {
            traversalList += city->p4->getName();
            distance += city->p4->weight4;

            std::cout << traversalList << std::endl
                      << "The total distance: " << distance << std::endl<< std::endl;
        }
        else if (city->p5 == startCity)
        {
            traversalList += city->p5->getName();
            distance += city->p5->weight5;

            std::cout << traversalList << std::endl
                      << "The total distance: " << distance << std::endl<< std::endl;
        }
    }
}

void Graph::traversal()
{
    float distance = 0;
    std::string list = startCity->getName();
    bruteTraversal(startCity, distance, list);
}