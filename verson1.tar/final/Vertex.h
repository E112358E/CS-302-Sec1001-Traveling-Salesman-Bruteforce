#ifndef VERTEX_H_
#define VERTEX_H_

#include <string>

class Graph;

class Vertex
{
    friend Graph;
    private:
        Vertex *p1, *p2, *p3, *p4, *p5; //five possible connections
        float weight1, weight2, weight3, weight4, weight5;
        std::string cityName;
        bool seen;
    public:
        Vertex(): p1(nullptr), p2(nullptr), p3(nullptr), p4(nullptr), p5(nullptr),
                  weight1(0), weight2(0), weight3(0), weight4(0), weight5(0), seen(false) {}
        Vertex(std::string name): p1(nullptr), p2(nullptr), p3(nullptr), p4(nullptr), p5(nullptr),
                                  weight1(0), weight2(0), weight3(0), weight4(0), weight5(0), seen(false)
        {
            setName(name);
        }
        float getWeight(int index)
        {
            switch(index)
            {
                case 1: return weight1;
                    break;
                case 2: return weight2;
                    break;
                case 3: return weight3;
                    break;
                case 4: return weight4;
                    break;
                default: return 0.0;
                    break;
            }
        }
        std::string getName()
        {
            return cityName;
        }
        void setName(const std::string &name)
        {
            cityName = name;
        }
        void revertSeen()
        {
            seen = false;
        }
};


#endif //VERTEX_H_