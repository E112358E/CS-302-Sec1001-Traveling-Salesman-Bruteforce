#include <iostream>
#include <string>
#include "Vertex.h"
#include "Graph.h"
//by: Elvis Vong
//test driver for the first version of Graph
using namespace std;

void setupVertices(Vertex *&vertex, std::string cityName);

int main()
{
    //setting up verticies for graph
    Vertex *A = nullptr, *B = nullptr, *C = nullptr, *D = nullptr, *E = nullptr;

    setupVertices(A, "Reno");
    setupVertices(B, "Seattle");
    setupVertices(C, "San_Francisco");
    setupVertices(D, "Las_Vegas");
    setupVertices(E, "Salt_Lake_City");

    //setting up the graph
    Graph roadMap;
    roadMap.setStart(A);
    roadMap.connectCities(B, A, 704.2);
    roadMap.connectCities(E, B, 829.9);
    roadMap.connectCities(D, E, 420.7);
    roadMap.connectCities(C, D, 568.8);

    roadMap.connectCities(C, B, 807.6);
    roadMap.connectCities(C, A, 218.4);
    roadMap.connectCities(A, E, 518.2);
    roadMap.connectCities(A, D, 439.0);

    //the traversal part
    roadMap.traversal();
    return 0;
}

void setupVertices(Vertex *&vertex, std::string cityName)
{
    vertex = new Vertex;
    vertex->setName(cityName);
}