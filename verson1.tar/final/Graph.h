#ifndef GRAPH_H_
#define GRAPH_H_

#include "Vertex.h"
//by: Elvis Vong
//first version just pure brute force no optimization
class Graph
{
    private:
        Vertex *startCity;
    public:
        Graph();
        Graph(const std::string cityName);
        ~Graph();

        void setStart(Vertex *newCity);
        void removeCity(Vertex *target);
        void connectCities(Vertex *cityA, Vertex *cityB, const float edge);
        float basicTraversal();// just a test traversal
        void bruteTraversal(Vertex *city, float distance, std::string traversalList);//recursive function that goes through all possiblities
        void traversal();//used to call brute traversal
        bool isEmpty();
};

#endif //GRAPH_H_